from .authorize_result import AuthorizeResult
